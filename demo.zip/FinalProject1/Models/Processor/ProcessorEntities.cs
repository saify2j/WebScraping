﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace FinalProject1.Models.Processor
{
    public partial class ProcessorEntities : DbContext
    {
        public virtual DbSet<DataProcessor> DataProcessor { get; set; }

        public ProcessorEntities(DbContextOptions<ProcessorEntities> options)
       : base(options) { }

      
        




        //        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //        {
        //            if (!optionsBuilder.IsConfigured)
        //            {
        //#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
        //                optionsBuilder.UseSqlServer(@"Data Source=DESKTOP-MVUN8U4\SQLEXPRESS;Database=newdb;Integrated Security=True");
        //            }
        //        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DataProcessor>(entity =>
            {
                entity.HasKey(e => e.ProId);

                entity.ToTable("data_processor");

                entity.Property(e => e.ProId)
                    .HasColumnName("pro_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.RyansPrice)
                    .IsRequired()
                    .HasColumnName("ryans-price")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.StarPrice)
                    .IsRequired()
                    .HasColumnName("star-price")
                    .HasMaxLength(200)
                    .IsUnicode(false);
            });
        }
    }
}
