﻿using System;
using System.Collections.Generic;

namespace FinalProject1.Models.Processor
{
    public partial class DataProcessor
    {
        public string Name { get; set; }
        public string RyansPrice { get; set; }
        public string StarPrice { get; set; }
        public int ProId { get; set; }

        internal dynamic findAll()
        {
            throw new NotImplementedException();
        }

        internal DataProcessor find(string id)
        {
            throw new NotImplementedException();
        }
    }
}
