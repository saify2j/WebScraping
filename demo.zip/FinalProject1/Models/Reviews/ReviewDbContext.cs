﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace FinalProject1.Models.Reviews
{
    public class ReviewDbContext: DbContext
    {
        public ReviewDbContext(DbContextOptions options):base (options)
        {

        }
        public DbSet<Review> Reviews { get; set; }

    }

}
