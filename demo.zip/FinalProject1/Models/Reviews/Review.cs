﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProject1.Models.Reviews
{
    public class Review
    {   
        //public Review() {  }
        [Key]
        public int review_id { get; set; }
        public int pro_id { get; set; }
        public string review { get; set; }
    }
}
