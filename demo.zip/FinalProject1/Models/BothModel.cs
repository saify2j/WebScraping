﻿using FinalProject1.Models.Processor;
using FinalProject1.Models.Reviews;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProject1.Models
{
    public class BothModel
    {
        public DataProcessor dmodel { get; set; }
        public Review review { get; set; }
    }
}
