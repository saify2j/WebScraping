﻿using FinalProject1.Models.Processor;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProject1.Models
{
    public class Item
    {
        public DataProcessor DataProcessor { get; set; }

    }
}
