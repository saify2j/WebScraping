﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FinalProject1.Models.Processor;
using FinalProject1.Models.Reviews;

namespace FinalProject1.Controllers
{
    public class DataProcessorsController : Controller
    {
        private readonly ProcessorEntities _context;

        public DataProcessorsController(ProcessorEntities context)
        {
            _context = context;
        }

        // GET: DataProcessors
       

        public async Task<IActionResult> Index(String searchkey)
        {
            DataProcessor productModel = new DataProcessor();
            
            var processors = from s in _context.DataProcessor select s;
            if (!String.IsNullOrEmpty(searchkey))
            {
                processors = processors.Where(s => s.Name.Contains(searchkey));
            }

            //return View(await _context.DataProcessor.ToListAsync());
            return View(await processors.ToListAsync());
        }

        // GET: DataProcessors/Details/5
        public async Task<IActionResult> Details(int? id)
        {

            if (id == null)
            {
                return NotFound();
            }

            var dataProcessor = await _context.DataProcessor
                .SingleOrDefaultAsync(m => m.ProId == id);
            if (dataProcessor == null)
            {
                return NotFound();
            }

            return View(dataProcessor);
        }

        // GET: DataProcessors/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: DataProcessors/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Name,RyansPrice,StarPrice,ProId")] DataProcessor dataProcessor)
        {
            if (ModelState.IsValid)
            {
                _context.Add(dataProcessor);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(dataProcessor);
        }

        // GET: DataProcessors/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dataProcessor = await _context.DataProcessor.SingleOrDefaultAsync(m => m.ProId == id);
            if (dataProcessor == null)
            {
                return NotFound();
            }
            return View(dataProcessor);
        }

        // POST: DataProcessors/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Name,RyansPrice,StarPrice,ProId")] DataProcessor dataProcessor)
        {
            if (id != dataProcessor.ProId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(dataProcessor);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DataProcessorExists(dataProcessor.ProId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(dataProcessor);
        }

        // GET: DataProcessors/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dataProcessor = await _context.DataProcessor
                .SingleOrDefaultAsync(m => m.ProId == id);
            if (dataProcessor == null)
            {
                return NotFound();
            }

            return View(dataProcessor);
        }

        // POST: DataProcessors/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var dataProcessor = await _context.DataProcessor.SingleOrDefaultAsync(m => m.ProId == id);
            _context.DataProcessor.Remove(dataProcessor);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DataProcessorExists(int id)
        {
            return _context.DataProcessor.Any(e => e.ProId == id);
        }
    }
}
